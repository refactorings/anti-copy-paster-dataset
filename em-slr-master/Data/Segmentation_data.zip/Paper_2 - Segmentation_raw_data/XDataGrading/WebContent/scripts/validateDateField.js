

/*
function validateDate(subject){
	  //if (subject.match(/^(?:(0[1-9]|1[012])[\- \/.](0[1-9]|[12][0-9]|3[01])[\- \/.](19|20)[0-9]{2})$/)){ 
	if (subject.match(/^(?:(0[1-9]|[12][0-9]|3[01])[\- \/.](0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/)){
	    return true;
	  }else{
	    return false;
	  }
	}

function validateTime(subject){
	  //if (subject.match(/^(?:(0[1-9]|1[012])[\- \/.](0[1-9]|[12][0-9]|3[01])[\- \/.](19|20)[0-9]{2})$/)){ 
	if (subject.match(/^(?:(0[0-9]|1[0-9]|2[0-3])[\: \/.]([0-5][0-9])[\: \/.]([0-5][0-9]))$/)){
	    return true;
	  }else{
	    return false;
	  }
	}


function validate(){
 /*
 if( document.assignmentForm.NumberOfQuestions.value == ""  ){
     alert( "Please provide Number of questions in the assignment !" );
     document.assignmentForm.NumberOfQuestions.focus() ;
     return false;
   }
   else{
	   <!-- checking for integers -->
	   var num = Number(document.assignmentForm.NumberOfQuestions.value);
	   
	   if (Math.floor(num) != num) {
		   alert("Please provide Number of questions in the assignment in integer format only !");
		   document.assignmentForm.NumberOfQuestions.focus();
		   return false;
	   }
   }
 */
 
 /*
   if( document.assignmentForm.startdate.value == "" ){
     alert( "Please provide  the start date for your assignment!" );
     document.assignmentForm.startdate.focus() ;
     return false;
   }
   
   else{
	   <!-- checking for ddate type -->
	   var result=validateDate(document.assignmentForm.startdate.value);
	   if( result==false){
		   alert("enter start date in DD-MM-YYYY format ");
		   document.assignmentForm.startdate.focus();
		   return false;
	   }
   }
     
   if( document.assignmentForm.starttime.value == "" ){
	     alert( "Please provide  the start time for your assignment!" );
	     document.assignmentForm.starttime.focus() ;
	     return false;
	   }
  
   else{
	   <!-- checking for ddate type -->
	   var result=validateTime(document.assignmentForm.starttime.value);
	   if( result==false){
		   alert("enter start time in HH:MM:SS(24hr) format ");
		   document.assignmentForm.starttime.focus();
		   return false;
	   }
   }   
   
   if( document.assignmentForm.enddate.value == ""){
     alert( "Please provide the end time for your assignment !" );
     document.assignmentForm.enddate.focus() ;
     return false;
   }
   else{
	   var result=validateDate( document.assignmentForm.enddate.value);
	   if( result==false){
		   alert("enter end date in DD-MM-YYYY format");
		   document.assignmentForm.enddate.focus() ;
		   return false;
	   }
   }
  
   if( document.assignmentForm.endtime.value == ""){
	     alert( "Please provide the end time for your assignment !" );
	     document.assignmentForm.endtime.focus() ;
	     return false;
	   }
  
   else{
	   <!-- checking for ddate type -->
	   var result=validateTime(document.assignmentForm.endtime.value);
	   if( result==false){
		   alert("enter end time in HH:MM:SS(24hr) format ");
		   document.assignmentForm.endtime.focus();
		   return false;
	   }
   }
  
  return true ;
}
*/


