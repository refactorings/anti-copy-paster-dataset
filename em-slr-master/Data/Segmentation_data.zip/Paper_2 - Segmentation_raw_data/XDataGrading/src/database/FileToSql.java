package database;
import java.util.*;
import java.io.*;
//CODE COPIED
public class FileToSql {

	 
    private static ArrayList<String> listOfQueries = null;  
      
    /* 
     * @param   path    Path to the SQL file 
     * @return          List of query strings  
     */  
    public static ArrayList<String> createQueries(String path) throws IOException  //Nd-0  
    {    
        String queryLine =      new String();  
        StringBuffer sBuffer =  new StringBuffer();  
        listOfQueries =         new ArrayList<String>();  //Nd-3
          
          
            FileReader fr =     new FileReader(new File(path));         //Nd-5
            BufferedReader br = new BufferedReader(fr);    //Nd-6
        
        /* start refactor parse lines with semicolon  */	//FTSRefactor#1 starts
            //read the SQL file line by line  
            while((queryLine = br.readLine()) != null)    //Nd-7,8
            {    
                // ignore comments beginning with #  
                int indexOfCommentSign = queryLine.indexOf('#');  
                if(indexOfCommentSign != -1)  //Nd-10
                {  
                    if(queryLine.startsWith("#"))  //Nd-12
                    {  
                        queryLine = new String("");  
                    }  
                    else   //Nd-14
                        queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));  
                }  
                // ignore comments beginning with --  
                indexOfCommentSign = queryLine.indexOf("--");  
                if(indexOfCommentSign != -1)  //Nd-18
                {  
                    if(queryLine.startsWith("--"))  //Nd-20
                    {  
                        queryLine = new String("");  
                    }  
                    else   //Nd-22
                        queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));  
                }  
                // ignore comments surrounded by /* */  
                indexOfCommentSign = queryLine.indexOf("/*");  
                if(indexOfCommentSign != -1)  //Nd-26
                {  
                
                
                /* start refactor parse block comment */	//FTSRefactor#2 starts
                    if(queryLine.startsWith("#"))  //Nd-28
                    {  
                        queryLine = new String("");  
                    }  
                    else  //Nd-30
                        queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));  
                      
                    sBuffer.append(queryLine + " ");   
                    // ignore all characters within the comment  
                    do  //Nd-35
                    {  
                        queryLine = br.readLine();  
                    }  
                    while(queryLine != null && !queryLine.contains("*/"));  
                    indexOfCommentSign = queryLine.indexOf("*/"); 
                     /* end refactor */	//FTSRefactor#2 ends
                    if(indexOfCommentSign != -1)  //Nd-38
                    {  
                        if(queryLine.endsWith("*/"))  
                        {  
                            queryLine = new String("");  
                        }  
                        else  
                            queryLine = new String(queryLine.substring(indexOfCommentSign+2, queryLine.length()-1));  
                    }  
                }  
                  
                //  the + " " is necessary, because otherwise the content before and after a line break are concatenated  
                // like e.g. a.xyz FROM becomes a.xyzFROM otherwise and can not be executed   
                if(queryLine != null)  //Nd-46
                    sBuffer.append(queryLine + " ");    
            }    
            br.close();  
            fr.close();
            /* end refactor */	//FTSRefactor#1 ends
            
            /* start refactor remove semicolons */	//FTSRefactor#3 starts
            // here is our splitter ! We use ";" as a delimiter for each request   
            String[] splittedQueries = sBuffer.toString().split(";");  
              
            // filter out empty statements  
            for(int i = 0; i<splittedQueries.length; i++)    //Nd-53
            {  
                if(!splittedQueries[i].trim().equals("") && !splittedQueries[i].trim().equals("\t"))   //Nd-58 
                {  
                    listOfQueries.add(new String(splittedQueries[i]));  
                }  
            }  
      /* end refactor */	//FTSRefactor#3 ends
      
        return listOfQueries;  
    }   
}
