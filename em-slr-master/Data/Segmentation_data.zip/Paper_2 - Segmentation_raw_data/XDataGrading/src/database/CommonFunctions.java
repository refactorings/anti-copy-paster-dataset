package database;

import java.util.*;
import java.util.logging.Logger;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.*;
import java.text.*;
import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class CommonFunctions {

	private static Logger logger = Logger.getLogger(CommonFunctions.class.getName());
	public String timeDifference(java.util.Date toDate, java.util.Date fromDate) {

		long diff = toDate.getTime() - fromDate.getTime();

		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000) % 24;
		long diffDays = diff / (24 * 60 * 60 * 1000);

		String timeDiff = diffDays + " days," + diffHours + " hours, "
				+ diffMinutes + " minutes, " + diffSeconds + " seconds.";

		System.out.print(diffDays + " days, ");
		System.out.print(diffHours + " hours, ");
		System.out.print(diffMinutes + " minutes, ");
		System.out.print(diffSeconds + " seconds.");

		return timeDiff;
	}
	
	/**
	 * This method gets the assignment details and instructions block
	 * for instructor mode 
	 * 
	 * @param courseID
	 * @param assignID
	 * @param link
	 * @return
	 * @throws Exception
	 */
	
	public String getAssignmentInstructions(String courseID, int assignID)
			throws Exception {
		return getAssignmentInstructions(courseID, assignID, "");	
	}

	
	public String getAssignmentInstructions(String courseID, int assignID,
			String link) throws Exception {	//Nd-17

		// get connection
		Timestamp end = null;
		int defaultSchemaId = 0;
		String assignmentName = null;
		String assignmentType="";
		String instructions = "<label><b>Assignment Id:</b></label> <b><label style='color:#353275'> " + assignID
				+ "</label><br/> ";
		try(Connection dbcon = (new DatabaseConnection()).dbConnection()){//Nd-23
				
			try(PreparedStatement stmt = dbcon
						.prepareStatement("SELECT * FROM xdata_assignment where assignment_id=? and course_id=?")){//Nd-25,26
				stmt.setInt(1, assignID);	//Nd-27
				stmt.setString(2, courseID);
				try(ResultSet rs = stmt.executeQuery()){	//Nd-29
					if (rs.next()) {	//Nd-31,32
					/* CFRefactor#1 start refactor append assignmentName and type to instructions */	//Not-extracted
						end = rs.getTimestamp("endtime");
						if(rs.getBoolean("learning_mode")){
							assignmentType="Learning Mode";
						}
						else{
							assignmentType="Grading Mode";
						}
						defaultSchemaId = rs.getInt("defaultschemaid");
						assignmentName = rs.getString("assignmentName");
						instructions += "<p></p><label><b>Assignment Name: </b></label> <b><label style='color:#353275'>"
								+ assignmentName + "</b></label>";
						instructions += "<p></p><label>Assignment Mode: </b></label> <b><label style='color:#353275'>"
								+ assignmentType + "</b></label>";
						/* end refactor */
						/* CFRefactor#2 start refactor append schema name etc. to instructions*/								
					try(PreparedStatement stmt1 = dbcon
								.prepareStatement("SELECT schema_name from xdata_schemainfo where course_id=? and schema_id=?")){	//Nd-43 //Match
							stmt1.setInt(2, defaultSchemaId);
							stmt1.setString(1, courseID);
							try(ResultSet rs1 = stmt1.executeQuery()){	//Nd-47
								if (rs1.next()) { //Nd-50
									instructions += "<p></p><label><b>Default Schema: </b></label> <b><label style='color:#353275'>"
											//+ rs1.getString("schema_name")
											+ "<span>&nbsp;</span>";
									instructions += "<a style=\"color:#353275;\" href=\"showSchemaFile.jsp?schema_id="
											+ defaultSchemaId
											+ "\">"+rs1.getString("schema_name")+"</a> </label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
								}
							}
						}
                        /* end refactor */
                        /* CFRefactor#3 start refactor append default schema id and sample data stuff */						
						try(PreparedStatement stmt1 = dbcon
								.prepareStatement("SELECT sample_data_name,sampledata_id from xdata_sampledata where course_id=? and schema_id=?")){	//Nd-54
							stmt1.setInt(2, defaultSchemaId);
							stmt1.setString(1, courseID);
							try(ResultSet rs1 = stmt1.executeQuery()){	//Nd-58	//This block Extracted but not listed
								if (rs1.next()) { //Nd-61
									instructions += "<p></p><label><b>Default dataset for data generation: </b></label> <b><label style='color:#353275'>"
											+ "<span>&nbsp;</span>";
									instructions += "<a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
											+defaultSchemaId+"&sampledata_id="+rs1.getString("sampledata_id")+"\">"+ rs1.getString("sample_data_name")+"</a></label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
								}
							}
							 
									Gson gson = new Gson();	//Nd-66
									Type listType = new TypeToken<String[]>() {}.getType();	//Extracted but not listed
									  if(rs.getString("defaultdsetid") != null || 
											  (rs.getString("defaultdsetid")!= null && rs.getString("defaultdsetid").equalsIgnoreCase("null"))){	//Nd-72
						                    String[] dsList = new Gson().fromJson(rs.getString("defaultdsetid"), listType);
						                  
											instructions += "<p></p><label><b>Default dataset(s) for evaluation: </b></label> <label style='color:#353275'>"
												//+ rs1.getString("schema_name")
												+ "<span>&nbsp;</span>";
											
											/*CFRefactor#4  start refactor weak refactor */	//Not extracted
											if(dsList != null && dsList.length != 0){	//Nd-76
						                    	for(int i=0;i<dsList.length;i++){	//Nd-78
						                    		try(ResultSet rs2 = stmt1.executeQuery()){//Nd-79
							                    		while(rs2.next()){	//Nd-81,82
							                    			if(rs2.getString("sampledata_id").equalsIgnoreCase(dsList[i])){	//Nd-85
							                    				String sampleDataName = rs2.getString("sample_data_name");
							                    				  instructions += "<b><a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
							                    							+defaultSchemaId+"&sampledata_id="+rs2.getString("sampledata_id")+"\">"+ rs2.getString("sample_data_name")+"</a></b>&nbsp;&nbsp;&nbsp;&nbsp;";
							                    				//break;
							                    			}
							                    		}
							                    		
						                    		}
						                    	}
						                    	instructions += "</label>&nbsp;&nbsp;&nbsp;&nbsp;";
						                    }
											else{	//Nd-92
											 instructions += "</label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
										  }
										/* end refactor */
							}
						}
						/* end refactor */
						
						/* CFRefactor#5 start refactor append time instructions */	//Partial Match 102-109
						SimpleDateFormat formatter = new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss");	//Nd-94
						formatter.setLenient(false);
						String ending = formatter.format(end);
						// String oldTime = "2012-07-11 10:55:21";
						java.util.Date oldDate = formatter.parse(ending);
						// get current date
						Calendar c = Calendar.getInstance();
						String currentDate = formatter.format(c.getTime());
						java.util.Date current = formatter.parse(currentDate);
						// compare times
						if (current.compareTo(oldDate) >= 0) {	//Nd-103
		
							CommonFunctions util = new CommonFunctions();
							String dueTime = util.timeDifference(current, oldDate);
							instructions +="<p><label><b> Assignment end date: </b></label> <b><label style='color:#353275'>"+end+ "  </b></label></p>";
							instructions += "<p><label> <b>Assignment is over due by </b></label> <b><label style='color:#353275'>"
									+ dueTime + "</b></label></p>";
						} else {
							instructions += "<p><label> <b>Assignment is due on </b></label> <b><label style='color:#353275'>"+ end
									+ "</label> </b></p>";
						}
						/* end refactor */
						
					}
					}//try block for resultset ends
			}//try block for statement ends
			}//try block for conn ends
		return instructions;	//Nd-110
	} 

	/**
	 * This method gets the assignment details for display in student mode
	 * 
	 * @param courseID
	 * @param assignID
	 * @return
	 * @throws Exception
	 */
	public String getStudentAssignmentInstructions(String courseID, int assignID,String user)//Nd-111
			throws Exception {
		// get connection
		Timestamp end = null;
		int defaultSchemaId = 0;
		String assignmentType = "";
		String assignmentName = null;
		String instructions = "";
		/*CFRefactor#6 start refactor insert header */	// Matched
		if(user.equals("guest")){ 	//Nd-118
			instructions += "<table border='0'><tr><td width='15%' style='padding: 0px;border:0px solid black;'>";
		}
		
		instructions += "<label><b>Assignment Id: </b></label> <b><label style='color:#353275'>" + assignID
				+ "</b></label>";
		if(user.equals("guest")){ //Nd-122
			instructions += "</td>"; 
		}
		/* end refactor */
		try(Connection dbcon = (new DatabaseConnection()).dbConnection()){	//Nd-124
			 
			try(PreparedStatement stmt = dbcon
					.prepareStatement("SELECT * FROM xdata_assignment where assignment_id=? and course_id=?")){	//Nd-126
			stmt.setInt(1, assignID);
			stmt.setString(2, courseID);
			try(ResultSet rs = stmt.executeQuery()){	//Nd-130
			if (rs.next()) {//Nd-133
				end = rs.getTimestamp("endtime");
				if(  rs.getBoolean("learning_mode")){	//Nd-136
					assignmentType="Learning Mode";
				}
				else{
					assignmentType="Grading Mode";
				}
				// start=rs.getString("end_date");
				defaultSchemaId = rs.getInt("defaultschemaid"); 
				assignmentName = rs.getString("assignmentName");
				if(!user.equals("guest")){ //Nd-143
					instructions += "<p></p>";
				}else{ 
					//instructions += "<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>";
				}
				if(user.equals("guest")){ //Nd-148
					instructions += "<td width='15%' style='padding: 0px;border:0px solid black;'>";
				}
				instructions += "<label><b>Assignment Name: </b></label> <b><label style='color:#353275' >"
						+ assignmentName + "</b></label>";
				if(user.equals("guest")){ //Nd-152
					instructions += "</td>";
				}
				if(!user.equals("guest")){ //Nd-155		//Extracted but not marked
					instructions += "<p></p>";
				}else{	//Nd-157
					//instructions += "<span>&nbsp;&nbsp;&nbsp;&nbsp;</span>";
					instructions += "<td width='15%' style='padding: 0px;border:0px solid black;'>";
				}
				instructions += "<label><b>Assignment Mode: </b></label> <b><label style='color:#353275'>"
						+ assignmentType + "</b></label>";
				if(user.equals("guest")){ 	//Nd-161
					instructions += "</td></tr><tr><td width='30%' style='padding: 0px;border:0px solid black;'>";
				}
				/*CFRefactor#7 start refactor try block as separate function */	//Matched
				try(PreparedStatement stmt1 = dbcon
						.prepareStatement("SELECT schema_name from xdata_schemainfo where course_id=? and schema_id=?")){//Nd-163
				stmt1.setInt(2, defaultSchemaId);
				stmt1.setString(1, courseID);
				try(ResultSet rs1 = stmt1.executeQuery()){//Nd-167
					if (rs1.next()) {	////Nd-170
						instructions += "<p></p><label><b>Default Schema:</b></label><span>&nbsp;</span><b><label style='color:#353275'>";
						instructions += "<a style=\"color:#353275;\" href=\"showSchemaFile.jsp?schema_id="
								+ defaultSchemaId + "\">"
								+ rs1.getString("schema_name")
								+ "</a></b></label>";
					}
				} 
				}
				/* end refactor */
				if(!user.equals("guest")){ //Nd-175		//Extracted but not matched
					instructions += "<p></p>";
				}
				else{
					instructions += "</td><td width='30%' style='padding: 0px;border:0px solid black;'>";
				}
				try(PreparedStatement stmt1 = dbcon
						.prepareStatement("SELECT sample_data_name,sampledata_id from xdata_sampledata where course_id=? and schema_id=?")){//Nd-179
					stmt1.setInt(2, defaultSchemaId);
					stmt1.setString(1, courseID);
					try(ResultSet rs1 = stmt1.executeQuery()){//Nd-183		//Extracted but not matched
						if (rs1.next()) { 	//Nd-186
							instructions += "<label><b>Default dataset for data generation: </b></label> <b><label style='color:#353275;'>"
									+ "<span>&nbsp;</span>";
							instructions += "<a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
									+defaultSchemaId+"&sampledata_id="+rs1.getString("sampledata_id")+"\">"+ rs1.getString("sample_data_name")+"</a></label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
						}
					}
					if(user.equals("guest")){ //Nd-192
						instructions += "</td></tr></table>";
					}
					if(!user.equals("guest")){ //Nd-195
					/*CFRefactor#8  start refactor around 30 lines extract as function */	//Matched; consider 'if' inside, otherwise 1% threshold
							Gson gson = new Gson();
							Type listType = new TypeToken<String[]>() {}.getType();
							  if(rs.getString("defaultdsetid") != null || 
									  (rs.getString("defaultdsetid")!= null && rs.getString("defaultdsetid").equalsIgnoreCase("null"))){//Nd-202
				                    String[] dsList = new Gson().fromJson(rs.getString("defaultdsetid"), listType);
				                  
									instructions += "<p></p><label><b>Default dataset(s) for evaluation: </b></label><label style='color:#353275'>"
										+ "<span>&nbsp;</span>";
									
									/*CFRefactor#9 start refactor weak refactor */		//Not matched
									if(dsList != null && dsList.length != 0){//Nd-206
				                    	for(int i=0;i<dsList.length;i++){//Nd-208
				                    		try(ResultSet rs2 = stmt1.executeQuery()){//Nd-209
					                    		while(rs2.next()){//Nd-212
					                    			if(rs2.getString("sampledata_id").equalsIgnoreCase(dsList[i])){//Nd-215
					                    				String sampleDataName = rs2.getString("sample_data_name");
					                    				  instructions += "<b><a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
					                    							+defaultSchemaId+"&sampledata_id="+rs2.getString("sampledata_id")+"\">"+ rs2.getString("sample_data_name")+"</a></b>&nbsp;&nbsp;&nbsp;&nbsp;";
					                    				//break;
					                    			}
					                    		}
				                    		}
				                    	}
				                    	instructions += "</label>";
				                    }
									else{//Nd-222
									 instructions += "</label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
									}
								/* end refactor */
								
					}
					/* end refactor */
				}
			}
				if(!user.equals("guest")){ //225
				/* CFRefactor#10 start refactor use the function append time stuff (refactored in previous function) */
					SimpleDateFormat formatter = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					formatter.setLenient(false);
					String ending = formatter.format(end);
					java.util.Date oldDate = formatter.parse(ending);
					// get current date
					Calendar c = Calendar.getInstance();
					String currentDate = formatter.format(c.getTime());
					java.util.Date current = formatter.parse(currentDate);
					// compare times
					if (current.compareTo(oldDate) >= 0) {	//Nd-235	//Partial match
	
						CommonFunctions util = new CommonFunctions();
						String dueTime = util.timeDifference(current, oldDate);
								instructions +="<p><label> <b>Assignment end date: </b></label> <b><label style='color:#353275'>"+end+ " </b></label></p>";					
						instructions += "<p><label><b> Assignment is over due by </b></label> <b><label style='color:#353275'>"
								+ dueTime + "</b></label></p>";					
					} else {//Nd-240
						instructions += "<p><label> <b>Assignment is due on </b></label> <b><label style='color:#353275'>" + end
								+ " </b></label></p>";
					}
					/* end refactor */
				}
			
			}
			}//try block for resultset ends
			}//try/block for stmnt ends
		}//try block for conn closeor
			return instructions;//Nd-242
	}

	
	public String getTesterAssignmentInstructions(String courseID, int assignID) throws Exception {//Nd-243
		// get connection
		Timestamp end = null;
		int defaultSchemaId = 0;
		String assignmentName = null;
		String assignmentType="";
		String instructions = "<label><b>Application Id:</b></label> <b><label style='color:#353275'> " + assignID
				+ "</label><br/> ";
		try(Connection dbcon = (new DatabaseConnection()).dbConnection()){//Nd-249
				 
			try(PreparedStatement stmt = dbcon
						.prepareStatement("SELECT * FROM xdata_assignment where assignment_id=? and course_id=?")){//Nd-251
				stmt.setInt(1, assignID);
				stmt.setString(2, courseID);
				try(ResultSet rs = stmt.executeQuery()){//Nd-255
					if (rs.next()) {//Nd-258
						// start=rs.getString("end_date");
						defaultSchemaId = rs.getInt("defaultschemaid");
						
						assignmentName = rs.getString("assignmentName");
						instructions += "<p></p><label><b>Application Name: </b></label> <b><label style='color:#353275'>"
								+ assignmentName + "</b></label>";
						
					/*CFRefactor#11 start refactor schema name and stuff */		//Matched
					try(PreparedStatement stmt1 = dbcon
								.prepareStatement("SELECT schema_name from xdata_schemainfo where course_id=? and schema_id=?")){//Nd-262
							stmt1.setInt(2, defaultSchemaId);
							stmt1.setString(1, courseID);
							try(ResultSet rs1 = stmt1.executeQuery()){//Nd-266
								if (rs1.next()) { //Nd-269
									instructions += "<p></p><label><b>Default Schema: </b></label> <b><label style='color:#353275'>"
											//+ rs1.getString("schema_name")
											+ "<span>&nbsp;</span>";
									instructions += "<a style=\"color:#353275;\" href=\"showSchemaFile.jsp?schema_id="
											+ defaultSchemaId
											+ "\">"+rs1.getString("schema_name")+"</a> </label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
								}
							}
						}
						/* end refactor */
						
						try(PreparedStatement stmt1 = dbcon
								.prepareStatement("SELECT sample_data_name,sampledata_id from xdata_sampledata where course_id=? and schema_id=?")){//Nd-273
							stmt1.setInt(2, defaultSchemaId);
							stmt1.setString(1, courseID);
							/*CFRefactor#12 start refactor data id and name */		//Matched
							try(ResultSet rs1 = stmt1.executeQuery()){//Nd-277
								if (rs1.next()) { //Nd-280
									instructions += "<p></p><label><b>Default dataset for data generation: </b></label> <b><label style='color:#353275'>"
											//+ rs1.getString("schema_name")
											+ "<span>&nbsp;</span>";
									instructions += "<a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
											+defaultSchemaId+"&sampledata_id="+rs1.getString("sampledata_id")+"\">"+ rs1.getString("sample_data_name")+"</a></label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
								}
							}
							 /* end refactor */
							 
							 /*CFRefactor#13 start refactor around 30 lines */		//Matched
									Gson gson = new Gson();//Nd-285
									Type listType = new TypeToken<String[]>() {}.getType();
									  if(rs.getString("defaultdsetid") != null || 
											  (rs.getString("defaultdsetid")!= null && rs.getString("defaultdsetid").equalsIgnoreCase("null"))){//Nd-291
						                    String[] dsList = new Gson().fromJson(rs.getString("defaultdsetid"), listType);
						                  
											instructions += "<p></p><label><b>Default dataset(s) for evaluation: </b></label> <label style='color:#353275'>"
												//+ rs1.getString("schema_name")
												+ "<span>&nbsp;</span>";
											
											if(dsList != null && dsList.length != 0){//Nd-295
						                    	for(int i=0;i<dsList.length;i++){//Nd-297
						                    		try(ResultSet rs2 = stmt1.executeQuery()){//Nd-298
							                    		while(rs2.next()){//Nd-301
							                    			if(rs2.getString("sampledata_id").equalsIgnoreCase(dsList[i])){
							                    				String sampleDataName = rs2.getString("sample_data_name");
							                    				  instructions += "<b><a style=\"color:#353275;\" href=\"showSampleData.jsp?schema_id="
							                    							+defaultSchemaId+"&sampledata_id="+rs2.getString("sampledata_id")+"\">"+ rs2.getString("sample_data_name")+"</a></b>&nbsp;&nbsp;&nbsp;&nbsp;";
							                    				//break;
							                    			}
							                    		}
							                    		
						                    		}
						                    	}
						                    	instructions += "</label>&nbsp;&nbsp;&nbsp;&nbsp;";
						                    }
											else{//Nd-311
											 instructions += "</label></b>&nbsp;&nbsp;&nbsp;&nbsp;";
										   // instructions += "<a style=\"\" href=\"showSampleData.jsp?schema_id="
											//		+defaultSchemaId+"&sampledata_id="+rs1.getString("sampledata_id")+">"+ rs1.getString("sample_data_name")+"</a> <br/>";
											}
							
							}
							/* end refactor */
						}
					}
					}//try block for resultset ends
			}//try block for statement ends
			}//try block for conn ends
		return instructions;//Nd-313
	} 
	
	/**
	 * This method encodes the query string from HTML and converts the special
	 * characters
	 * 
	 * @param s
	 * @return
	 */
	public static String encodeHTML(String s) {
		StringBuffer out = new StringBuffer();
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c > 127 || c == '"' || c == '<' || c == '>') {
				out.append("&#" + (int) c + ";");
			} else {
				out.append(c);
			}
		}
		return out.toString();
	}

	/**
	 * Decodes the passed UTF-8 String using an algorithm that's compatible with
	 * JavaScript's <code>decodeURIComponent</code> function. Returns
	 * <code>null</code> if the String is <code>null</code>.
	 * 
	 * @param s
	 *            The UTF-8 encoded String to be decoded
	 * @return the decoded String
	 */
	public static String decodeURIComponent(String s) {
		if (s == null) {
			return null;
		}

		String result = null;

		try {
			s = s.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
			s = s.replaceAll("\\+", "%2B");
			result = URLDecoder.decode(s, "UTF-8");
		}
		// This exception should never occur.
		catch (UnsupportedEncodingException e) {
			result = s;

		}

		return result;
	}

	/**
	 * Encodes the passed String as UTF-8 using an algorithm that's compatible
	 * with JavaScript's <code>encodeURIComponent</code> function. Returns
	 * <code>null</code> if the String is <code>null</code>.
	 * 
	 * @param s
	 *            The String to be encoded
	 * @return the encoded String
	 */
	public static String encodeURIComponent(String s) {
		String result = null;

		try {
			result = URLEncoder.encode(s, "UTF-8");
		}

		// This exception should never occur.
		catch (UnsupportedEncodingException e) {
			result = s;
		}

		return result;
	}

}
