package testDataGen;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.lang.reflect.Type;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import util.*;


public class PopulateTestDataGrading {

	private static Logger logger = Logger.getLogger(PopulateTestDataGrading.class.getName());

	

	public void fetchAndPopulateTestDatabase(Connection dbcon, Connection testCon, int assignment_id,int question_id, int query_id, String course_id, String dataset_id,TableMap tableMap) throws Exception{

		String dataset_query="select value from xdata_datasetvalue where datasetid =? and assignment_id=? and question_id=? and query_id=? and course_id = ?";
		String dataset= "";

		PreparedStatement dstmt = dbcon.prepareStatement(dataset_query);
		dstmt.setString(1,dataset_id);
		dstmt.setInt(2, assignment_id);
		dstmt.setInt(3,question_id);
		dstmt.setInt(4,query_id);
		dstmt.setString(5,course_id);
		logger.log(Level.FINE,"Dataset_id is :"+dataset_id);
		logger.log(Level.FINE,"Query_id is :"+query_id);
		ResultSet dset=dstmt.executeQuery();
		try{
			while(dset.next()){
				dataset = dset.getString("value");

				Map<String , ArrayList> tables=new HashMap<String , ArrayList>();
				Gson gson = new Gson();
				//ArrayList dsList = gson.fromJson(value,ArrayList.class);
				Type listType = new TypeToken<ArrayList<DataSetValue>>() {
				}.getType();
				List<DataSetValue> dsList = new Gson().fromJson(dataset, listType);
				logger.log(Level.INFO,"dsList.size() = "+ dsList.size());
	/*segment22-41: begins*/	//Notmatch		 /// 2
				for(int i = 0 ; i < dsList.size();i++ ){
					DataSetValue dsValue = dsList.get(i);
					String tname,values; 
					if(dsValue.getFilename().contains(".ref.")){
						tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".ref.copy"));
					}else{
						tname = dsValue.getFilename().substring(0,dsValue.getFilename().indexOf(".copy"));
					}
					logger.log(Level.FINE,"table String:::::::::::::::::::::::::::"+tname);
					//for(String dsv: dsValue.getDataForColumn()){
					tables.put(tname, dsValue.getDataForColumn());	
					//}
				}
	/*segment22-41: ends*/
				int size = tableMap.foreignKeyGraph.topSort().size();
				for (int i=(size-1);i>=0;i--){
					String tableName = tableMap.foreignKeyGraph.topSort().get(i).toString();
					String del="delete from "+tableName;
					logger.log(Level.FINE,"DELETE::::::::::::::::::::::::"+del);
					PreparedStatement stmt=testCon.prepareStatement(del);
					try{
						stmt.executeUpdate();
					}catch(Exception e){
						logger.log(Level.SEVERE,"PopulateTestData.fetchAndPopulateTestDatabase -> ERROR:" + del,e);
						//logger.log(Level.SEVERE, ""+e.getStackTrace(),e);
						//e.printStackTrace();
					}finally{
						stmt.close();
					}
				}
				//If tables ontains foreign key relation they will be available in foreignKeyGraph
				//start PTRefactor#1
				for(int i=0;i<tableMap.foreignKeyGraph.topSort().size();i++){ /// insertData
					String tableName = tableMap.foreignKeyGraph.topSort().get(i).toString();
					if(tables.containsKey(tableName)){
						ArrayList <String> value=tables.get(tableName);

						for(String column: value)
						{
							String row=column.replaceAll("\\|", "','");
							String insert="insert into "+tableName+" Values ('"+row+"')";
							logger.log(Level.FINE,"Insert statement:::::::::::::::::::::::"+insert);

							PreparedStatement inst=testCon.prepareStatement(insert);
							try{
								inst.executeUpdate();
								tables.remove(tableName);
							}catch(Exception e){
								logger.log(Level.INFO,"PopulateTestData.fetchAndPopulateTestDatabase -> ERROR:" + insert);
								//logger.log(Level.SEVERE,""+e.getStackTrace(),e);
								//e.printStackTrace();
							}finally{
								inst.close();
							}
						}
					} 
				} 
		//end PTRefactor#1		
				//Tables that are not in foreign key relation, just insert without any checks
				//Shree added this for relations not having foreign key
				
		//start PTRefactor#2		
				Iterator it = tables.entrySet().iterator();
				while(it.hasNext()){  /// insertData similar to above

					java.util.Map.Entry<String,ArrayList> ent= (Map.Entry<String,ArrayList>)it.next();
					String tableName  = ent.getKey();
					ArrayList <String> value=ent.getValue();
					for(String column: value)
					{
						String row=column.replaceAll("\\|", "','");
						String insert="insert into "+tableName+" Values ('"+row+"')";
						logger.log(Level.INFO,"Insert statement:::::::::::::::::::::::"+insert);

						PreparedStatement inst=testCon.prepareStatement(insert);
						try{
							inst.executeUpdate(); 
							it.remove();//remove(tableName);
						}catch(Exception e){ 
							logger.log(Level.INFO,"PopulateTestData.fetchAndPopulateTestDatabase -> ERROR:" + insert);
							//logger.log(Level.SEVERE,""+e.getStackTrace(),e);
							//e.printStackTrace();
						}finally{
							inst.close();
						}
					}
				}
		//PTRefactor#2

			}
		}catch(Exception e){
			logger.log(Level.SEVERE,""+e.getStackTrace(),e);
			dbcon.close();
			testCon.close();
			//e.printStackTrace();
			throw e;
		}finally{
			dset.close();
			dstmt.close();


		}
	}

	public void fetchAndPopulateTestDatabase(int assignment_id, int question_id, int query_id, String course_id, String dataset_id,TableMap tableMap) throws Exception{
		//Connection dbcon = MyConnection.getExistingDatabaseConnection();
		//Connection testCon = MyConnection.getTestDatabaseConnection();

		try(Connection dbcon = MyConnection.getDatabaseConnection()){
			try(Connection testCon = (new DatabaseConnection().getTesterConnection(assignment_id)).getTesterConn()){
				fetchAndPopulateTestDatabase(dbcon, testCon, assignment_id, question_id,query_id,course_id, dataset_id, tableMap);
			}
		}catch(Exception e){
			logger.log(Level.SEVERE,"PopulateTestData Class:  "+e.getStackTrace(),e);
		}

	}


	
	public void populateTestDataForTesting(Vector<String> listOfCopyFiles, String filePath, TableMap tableMap, Connection conn, int assignmentId, int questionId){
		try{						
			deleteAllTempTablesFromTestUser(conn);
			//deleteAllTablesFromTestUser(conn);
			this.createTempTables(conn, assignmentId, questionId);
			BufferedReader br = null;

			for(int i=0;i<tableMap.foreignKeyGraph.topSort().size();i++){
				try{
			//start PTRefactor#3	
					String tableName = tableMap.foreignKeyGraph.topSort().get(i).toString();
		/*segment138-163: begins*/	//Match		 /// 4 uploadTableMapData begin one line before
					if(listOfCopyFiles.contains(tableName+".copy")){
						listOfCopyFiles.remove(tableName+".copy");
						String copyFile = tableName+".copy";

						br = new BufferedReader(new FileReader(Configuration.homeDir+"/temp_cvc"+filePath+"/"+copyFile));
						String str;
						String data="";
						while((str = br.readLine())!=null){
							data+=str+"@@";
						}

						uploadTestDataToTempTables(copyFile.substring(0, copyFile.indexOf(".copy")), data, filePath, conn);
					}else if(listOfCopyFiles.contains(tableName+".ref.copy")){
						listOfCopyFiles.remove(tableName+".ref.copy");
						String copyFile = tableName+".ref.copy";
						br = new BufferedReader(new FileReader(Configuration.homeDir+"/temp_cvc"+filePath+"/"+copyFile));
						String str;
						String data="";
						while((str = br.readLine())!=null){
							data+=str+"@@";
						}

						uploadTestDataToTempTables(copyFile.substring(0, copyFile.indexOf(".ref.copy")), data, filePath, conn);
					}
					
		//ends PTRefactor#3				
		/*segment138-163: ends*/			
				}catch(Exception e){
					logger.log(Level.SEVERE,"PopulateTestData.populateTestDataForTesting(): "+e.getStackTrace(),e);
				}finally{
					if(br != null){
						br.close();
					}
				}

			}
		//start PTRefactor#4		
			for(int i=0;i<listOfCopyFiles.size();i++){ /// uploadData - can be called from previous function
				try{
					String copyFile = listOfCopyFiles.get(i);
					br = new BufferedReader(new FileReader(Configuration.homeDir+"/temp_cvc"+filePath+"/"+copyFile));
					String str;
					String data="";
					while((str = br.readLine())!=null){
						data+=str+"@@";
					}

					uploadTestDataToTempTables(copyFile.substring(0,copyFile.indexOf(".copy")), data, filePath, conn);
				}catch(Exception e){
					logger.log(Level.SEVERE,"PopulateTestData.populateTestDataForTesting(): "+e.getStackTrace(),e);
				}
				finally{
					if(br != null)
						br.close();
				}
			}
			
	//ends PTRefactor#4
		}catch(Exception e){
			logger.log(Level.SEVERE,"PopulateTestData.populateTestDataForTesting: "+e.getStackTrace(),e);
			//e.printStackTrace();
		}finally{

			//conn.close();

		}


	}


	public void uploadTestDataToTempTables(String tablename,String copyFileData,String filePath, Connection conn) throws Exception{			
		String t[]=copyFileData.split("@@");
		for(int i=0;i<t.length;i++){			
			t[i]=t[i].replaceAll("\\|", "','");

			PreparedStatement smt=conn.prepareStatement("Insert into "+ tablename+" Values ('"+t[i]+"')");
			try{
				smt.executeUpdate();

			}catch(Exception e){
				//logger.log(Level.SEVERE,"PopulateTestData:uploadTestDataToTempTables->Error in "+tablename+"Insert into "+ tablename+" Values ('"+t[i]+"')",e);
				//logger.log(Level.SEVERE,e.getMessage(),e);
				//e.printStackTrace();
			}finally{
				smt.close();
			}

		}				
	}

	public void deleteAllTempTablesFromTestUser(Connection dbConn) throws Exception{
		Statement st = dbConn.createStatement();
		st = dbConn.createStatement();
		st.executeUpdate("DISCARD TEMPORARY");
		st.close();
	}

	public void deleteAllTablesFromTestUser(Connection conn) throws Exception{
		try{
			DatabaseMetaData dbm = conn.getMetaData();
			String[] types = {"TEMPORARY TABLE"};
			ResultSet rs = dbm.getTables(conn.getCatalog(), null, "%", types);		  

			while(rs.next()){
				String table=rs.getString("TABLE_NAME");		
				if(!table.equalsIgnoreCase("dataset") 
						&& !table.equalsIgnoreCase("xdata_temp1")
						&& !table.equalsIgnoreCase("xdata_temp2")){
					//PreparedStatement pstmt = conn.prepareStatement("delete from "+table);						
					PreparedStatement pstmt = conn.prepareStatement("Truncate table "+table +" cascade");
					pstmt.executeUpdate();
					pstmt.close();
				}

			} 

			rs.close();
		}catch(Exception e){
			logger.log(Level.SEVERE,e.getMessage(),e);
		}

	}

	public void deleteDatasets(String filePath) throws Exception{
		//Runtime r = Runtime.getRuntime();
		File f=new File(Configuration.homeDir+"/temp_cvc"+filePath+"/");
		File f2[]=f.listFiles();
		for(int i=0;i<f2.length;i++){
			if(f2[i].isDirectory() && f2[i].getName().startsWith("DS")){
				Utilities.deletePath(Configuration.homeDir+"/temp_cvc"+filePath+"/"+f2[i].getName());
			}				
		}
	}

	//TODO:Refractor this method name and input prarameters. 
	//This is no longer used to check how many mutants were killed
	
	public void createTempTables(Connection conn, int assignId, int questionId) throws Exception {
		//Connection mainConn = MyConnection.getExistingDatabaseConnection();
		try(Connection mainConn = MyConnection.getDatabaseConnection()){	
			int schemaId = 0, optionalSchemaId=0;			

			try(PreparedStatement stmt = mainConn.prepareStatement("select defaultschemaid from xdata_assignment where assignment_id = ?")){
				stmt.setInt(1, assignId); 

				try(ResultSet result = stmt.executeQuery()){
				
		//PTRefactor#5	
					//Get optional Schema Id for this question
					try(PreparedStatement stmt1 = mainConn.prepareStatement("select optionalschemaid from xdata_qinfo where assignment_id = ? and question_id= ? ")){
						stmt1.setInt(1, assignId); 
						stmt1.setInt(2, questionId); 

						try(ResultSet resultSet = stmt1.executeQuery()){
							if(resultSet.next()){
								optionalSchemaId = resultSet.getInt("optionalschemaid");
							}
						}
					}
	//PTRefactor#5			 
					if(result.next()){
						//If optional schema id exists and it is not same as default schema id, then set it as schemaId 
						if(optionalSchemaId != 0 && optionalSchemaId != result.getInt("defaultschemaid")){	
							schemaId = optionalSchemaId;
						} else{
							schemaId = result.getInt("defaultschemaid");
						}
					}

					if(schemaId != 0){	
					
					//PTRefactor#6			  ///  createTables
						try(PreparedStatement stmt1 = mainConn.prepareStatement("select ddltext from xdata_schemainfo where schema_id = ?")){
							stmt1.setInt(1, schemaId);			
							try(ResultSet result1 = stmt1.executeQuery()){

								// Process the result			
								if(result1.next()){
									String fileContent= result1.getString("ddltext");
									byte[] dataBytes = fileContent.getBytes();
									String tempFile = "/tmp/dummy";

									FileOutputStream fos = new FileOutputStream(tempFile);
									fos.write(dataBytes);
									fos.close();

									ArrayList<String> listOfQueries = Utilities.createQueries(tempFile);
									String[] inst = listOfQueries.toArray(new String[listOfQueries.size()]);

									for (int i = 0; i < inst.length; i++) {
										// we ensure that there is no spaces before or after the request string  
										// in order to not execute empty statements  
										if (!inst[i].trim().equals("") && ! inst[i].trim().contains("drop table")) {
											String temp = inst[i].replaceAll("(?i)^[ ]*create[ ]+table[ ]+", "create temporary table ");
											try(PreparedStatement stmt2 = conn.prepareStatement(temp)){
												stmt2.executeUpdate();					
											}
										}
									}	
								}
							}//try-with-resource for ressultset result
						}//try-with-resource for stmt1
				//ends PTRefactor#6				
					}	
				}//try-with-resource for ResultSet
			}//Try-with-resource for statement obj
		}//try-with-resource for Connection obj
		catch(Exception ex){
			logger.log(Level.SEVERE,ex.getMessage(),ex);
			//ex.printStackTrace();
			throw ex;
		}


	}

	public void createTempTablesForDemoUI(Connection conn, int assignId, int questionId) throws Exception {
		//Connection mainConn = MyConnection.getExistingDatabaseConnection();
		Connection mainConn = conn;	
			int schemaId = 0, optionalSchemaId=0;			

			try(PreparedStatement stmt = mainConn.prepareStatement("select defaultschemaid from xdata_assignment where assignment_id = ?")){
				stmt.setInt(1, assignId); 

				try(ResultSet result = stmt.executeQuery()){
		//PTRefactor#7		
/*segment319-327: begins*/ // Match/// 4 getOptionalSchemaId
					//Get optional Schema Id for this question
					try(PreparedStatement stmt1 = mainConn.prepareStatement("select optionalschemaid from xdata_qinfo where assignment_id = ? and question_id= ? ")){
						stmt1.setInt(1, assignId); 
						stmt1.setInt(2, questionId); 

						try(ResultSet resultSet = stmt1.executeQuery()){
							if(resultSet.next()){
								optionalSchemaId = resultSet.getInt("optionalschemaid");
							}
						}
					}
			// ends PTRefactor#7		
		/*segment319-327: ends*/			
					if(result.next()){
						//If optional schema id exists and it is not same as default schema id, then set it as schemaId 
						if(optionalSchemaId != 0 && optionalSchemaId != result.getInt("defaultschemaid")){	
							schemaId = optionalSchemaId;
						} else{
							schemaId = result.getInt("defaultschemaid");
						}
					}

					if(schemaId != 0){				  ///  createTables
					//start PTRefactor#8
						try(PreparedStatement stmt1 = mainConn.prepareStatement("select ddltext from xdata_schemainfo where schema_id = ?")){
							stmt1.setInt(1, schemaId);			
							try(ResultSet result1 = stmt1.executeQuery()){

								// Process the result			
								if(result1.next()){
									String fileContent= result1.getString("ddltext");
									byte[] dataBytes = fileContent.getBytes();
									String tempFile = "/tmp/dummy";

									FileOutputStream fos = new FileOutputStream(tempFile);
									fos.write(dataBytes);
									fos.close();

									ArrayList<String> listOfQueries = Utilities.createQueries(tempFile);
									String[] inst = listOfQueries.toArray(new String[listOfQueries.size()]);

									for (int i = 0; i < inst.length; i++) {
										// we ensure that there is no spaces before or after the request string  
										// in order to not execute empty statements  
										if (!inst[i].trim().equals("") && ! inst[i].trim().contains("drop table")) {
											String temp = inst[i].replaceAll("(?i)^[ ]*create[ ]+table[ ]+", "create temporary table ");
											try(PreparedStatement stmt2 = conn.prepareStatement(temp)){
												stmt2.executeUpdate();					
											}
										}
									}	
								}
							}//try-with-resource for ressultset result
						}//try-with-resource for stmt1
			//end PTRefactor#8					
					}	
				}//try-with-resource for ResultSet
			}//Try-with-resource for statement obj
	}

	public void createTempTablesForTestThread(Connection conn, int assignId, int questionId) throws Exception {
		//Connection mainConn = MyConnection.getExistingDatabaseConnection();
		try(Connection mainConn = MyConnection.getDatabaseConnection()){	
			int schemaId = 0, optionalSchemaId=0;			

			try(PreparedStatement stmt = mainConn.prepareStatement("select defaultschemaid from xdata_assignment where assignment_id = ?")){
				stmt.setInt(1, assignId); 

				try(ResultSet result = stmt.executeQuery()){

	// start PTRefactor#9
		/*segment374-382: begins*/ // Match /// 4 getOptionalSchemaId
					//Get optional Schema Id for this question
					try(PreparedStatement stmt1 = mainConn.prepareStatement("select optionalschemaid from xdata_qinfo where assignment_id = ? and question_id= ? ")){
						stmt1.setInt(1, assignId); 
						stmt1.setInt(2, questionId); 

						try(ResultSet resultSet = stmt1.executeQuery()){
							if(resultSet.next()){
								optionalSchemaId = resultSet.getInt("optionalschemaid");
							}
						}
					}
	//ends PTRefactor#9				
	/*segment374-382: ends*/				
					if(result.next()){
						//If optional schema id exists and it is not same as default schema id, then set it as schemaId 
						if(optionalSchemaId != 0 && optionalSchemaId != result.getInt("defaultschemaid")){	
							schemaId = optionalSchemaId;
						} else{
							schemaId = result.getInt("defaultschemaid");
						}
					}

					if(schemaId != 0){
		//start PTRefactor#10			 ///  createTables
						try(PreparedStatement stmt1 = mainConn.prepareStatement("select ddltext from xdata_schemainfo where schema_id = ?")){
							stmt1.setInt(1, schemaId);			
							try(ResultSet result1 = stmt1.executeQuery()){

								// Process the result			
								if(result1.next()){
									String fileContent= result1.getString("ddltext");
									byte[] dataBytes = fileContent.getBytes();
									String tempFile = "/tmp/dummy";

									FileOutputStream fos = new FileOutputStream(tempFile);
									fos.write(dataBytes);
									fos.close();

									ArrayList<String> listOfQueries = Utilities.createQueries(tempFile);
									String[] inst = listOfQueries.toArray(new String[listOfQueries.size()]);

									for (int i = 0; i < inst.length; i++) {
										// we ensure that there is no spaces before or after the request string  
										// in order to not execute empty statements  
										if (!inst[i].trim().equals("") && ! inst[i].trim().contains("drop table")) {
											String temp = inst[i].replaceAll("(?i)^[ ]*create[ ]+table[ ]+", "create temporary table ");
											try(PreparedStatement stmt2 = conn.prepareStatement(temp)){
												stmt2.executeUpdate();					
											}
										}
									}	
								}
							}//try-with-resource for ressultset result
						}//try-with-resource for stmt1	
		//PTRefactor#10					
					}	
				}//try-with-resource for ResultSet
			}//Try-with-resource for statement obj
		}//try-with-resource for Connection obj
		catch(Exception ex){
			logger.log(Level.SEVERE,ex.getMessage(),ex);
			//ex.printStackTrace();
			throw ex;
		}


	}


	/**
	 * This method is used in TestAnswer class for evaluating the queries.
	 * If data generation fails, then this method is called while evaluation 
	 * and default sample data is loaded and is taken as dataset against which evaluation is done.
	 *  
	 * @param conn
	 * @param testConn
	 * @param assignmentId
	 * @param questionId
	 * @throws Exception
	 */
	public void createTempTableData(Connection conn, Connection testConn, int assignmentId, int questionId,String course_id) throws Exception{
		int connId = 2, schemaId = 15,optionalSchemaId=15;

		try(PreparedStatement stmt = conn.prepareStatement("select connection_id, defaultschemaid from xdata_assignment where assignment_id = ? and course_id = ?")){
			stmt.setInt(1, assignmentId);
			stmt.setString(2,course_id);
/*segment431-450: begins*/ /// 2 // Notmatch
			try(ResultSet result = stmt.executeQuery()){

/*segment433-442: begins*/ //MAtch/// 4 getOptionalSchemaId
//	start PTRefactor#11
				//Get optional Schema Id for this question
				try(PreparedStatement statement = conn.prepareStatement("select optionalschemaid from xdata_qinfo where assignment_id = ? and question_id= ? and course_id = ?")){
					statement.setInt(1, assignmentId); 
					statement.setInt(2,questionId); 
					statement.setString(3,course_id);

					try(ResultSet resultSet = statement.executeQuery()){
						if(resultSet.next()){
							optionalSchemaId = resultSet.getInt("optionalschemaid");			
						}
					} //try-with-resources - ResultSet -resultSet obj
				}//try-with-resources -PreparedStatement statement obj
	//	ends PTRefactor#11			
/*segment433-442: ends*/				
				if(result.next()){
					connId = result.getInt("connection_id");			
					//If optional schema id exists and it is not same as default schema id, then set it as schemaId 
					if(optionalSchemaId != 0 && optionalSchemaId != result.getInt("defaultschemaid")){	
						schemaId = optionalSchemaId;
					} else{
						schemaId = result.getInt("defaultschemaid");
					}
				} 
			}//try-with-resource - ResultSet obj
			
	/*segment431-450: ends*/		
		}//try-with-resource - Preparedstmt obj
		byte[] dataBytes = null;
		String tempFile = "";
		FileOutputStream fos = null;
		ArrayList<String> listOfQueries = null;
		String[] inst = null;
		if(connId != 0 && schemaId != 0){
		
		//PTRefactor#12
		/*segment457-484: begins*/ //MAtch/// 4 createTable
			try(PreparedStatement stmt = conn.prepareStatement("select ddltext from xdata_schemainfo where schema_id = ?")){
				stmt.setInt(1, schemaId);			
				try(ResultSet result = stmt.executeQuery()){

					// Process the result			
					if(result.next()){
						String fileContent= result.getString("ddltext");
						//String fr=fileContent.replace("\\\\","'");
						//String fc = fr.replace("\t", "    ");
						dataBytes = fileContent.getBytes();
						tempFile = "/tmp/dummy";

						fos = new FileOutputStream(tempFile);
						fos.write(dataBytes);
						fos.close();

						listOfQueries = Utilities.createQueries(tempFile);
						inst = listOfQueries.toArray(new String[listOfQueries.size()]);

						for (int i = 0; i < inst.length; i++) {
							// we ensure that there is no spaces before or after the request string  
							// in order to not execute empty statements  
							if (!inst[i].trim().equals("") && ! inst[i].trim().contains("drop table")) {
								String temp = inst[i].replaceAll("(?i)^[ ]*create[ ]+table[ ]+", "create temporary table ");
								try(PreparedStatement stmt2 = testConn.prepareStatement(temp)){
									stmt2.executeUpdate();	
								}
							}
						}
					}
				}
			}
	//ends PTRefactor#12		
	/*segment457-484: ends*/		
			try(PreparedStatement stmt = conn.prepareStatement("select sample_data from xdata_sampledata where schema_id = ?")){  ///  uploadData
				stmt.setInt(1, schemaId);			
				try(ResultSet result = stmt.executeQuery()){

					// Process the result			
					if(result.next()){
						String sdContent= result.getString("sample_data");
						//String sdReplace=sdContent.replace("\\\\","'");
						//fc = sdReplace.replace("\t", "    ");
						dataBytes = sdContent.getBytes(); 
						fos = new FileOutputStream(tempFile);
						fos.write(dataBytes);
						fos.close();

						listOfQueries = Utilities.createQueries(tempFile);
						inst = listOfQueries.toArray(new String[listOfQueries.size()]);

						for (int i = 0; i < inst.length; i++) {
							// we ensure that there is no spaces before or after the request string  
							// in order to not execute empty statements  
							if (!inst[i].trim().equals("") && !inst[i].contains("drop table") && !inst[i].contains("delete from")) {
								//System.out.println(inst[i]);
								try(PreparedStatement stmt2 = testConn.prepareStatement(inst[i])){
									stmt2.executeUpdate();		
								}
							}
						}

					}//try-with-resource resultset obj
				}//try-with-resource statement obj	
			}
		}

	}

	/**For the instructor given data sets during assignment creation
test student and instructor query options */
	/**
	 * First get sample data sets for question, if it is not there, then get
	 * it from assignment table
	 * If both are not there, dont set anythng
	 * @throws SQLException 
	 * @throws FileNotFoundException 
	 * @throws IOException
	 */
	public String createTempTableWithDefaultData(Connection mainCon,Connection testConn,int assignmentId,
			int questionId,String course_id,String sampledata_id) throws Exception{
		String sampleDataName = "";
		byte[] dataBytes = null;
		String tempFile = "";
		FileOutputStream fos = null;
		ArrayList<String> listOfQueries = null;
		String[] inst = null;
		this.deleteAllTablesFromTestUser(testConn);
		try(PreparedStatement stmt = mainCon.prepareStatement("select sample_data_name,sample_data from xdata_sampledata where sampledata_id = ?")){
			stmt.setInt(1, Integer.parseInt(sampledata_id));			
	/*segment523-547:begins*/		 /// 4 uploadData
			try(ResultSet result = stmt.executeQuery()){
				// Process the result			
				if(result.next()){
					sampleDataName = result.getString("sample_data_name");
					String sdContent= result.getString("sample_data");
					//String sdReplace=sdContent.replace("\\\\","'");
					//fc = sdReplace.replace("\t", "    ");
					tempFile = "/tmp/dummy";
					dataBytes = sdContent.getBytes(); 
					fos = new FileOutputStream(tempFile);
					fos.write(dataBytes);
					fos.close();

					listOfQueries = Utilities.createQueries(tempFile);
					inst = listOfQueries.toArray(new String[listOfQueries.size()]);

					for (int i = 0; i < inst.length; i++) {
						// we ensure that there is no spaces before or after the request string  
						// in order to not execute empty statements  
						if (!inst[i].trim().equals("") && !inst[i].contains("drop table") && !inst[i].contains("delete from")) {
							//System.out.println(inst[i]);
							try(PreparedStatement stmt2 = testConn.prepareStatement(inst[i])){
								stmt2.executeUpdate();		
							}
						}
					}

				}//try-with-resource resultset obj
			}//try-with-resource statement obj	
	/*segment523-547:ends*/		
		} catch (SQLException e) {
			logger.log(Level.INFO,"------PopulateTestData - Load default data sets------");
			logger.log(Level.SEVERE,e.getMessage(),e);
			//throw e;
		}
		catch (FileNotFoundException e) {
			logger.log(Level.INFO,"------PopulateTestData - Load default data sets------");
			logger.log(Level.SEVERE,e.getMessage(),e);
			//throw e;
		}
		catch (IOException e) {
			logger.log(Level.INFO,"------PopulateTestData - Load default data sets------");
			logger.log(Level.SEVERE,e.getMessage(),e);
			//throw e;
		}
		return sampleDataName;

	}
	public void populateDataset(int assignmentId, int questionId, int query_id, String course_id, String datasetId, Connection mainConn, Connection testConn) throws Exception{
		GenerateCVC1 cvc = new GenerateCVC1();		
		preProcessForDataGeneration p = new preProcessForDataGeneration();
		cvc.setAssignmentId(assignmentId);
		cvc.setQuestionId(questionId);
		cvc.setQueryId(1);
		cvc.setCourseId(course_id);
		
		p.initializeConnectionDetails(cvc);
		TableMap tm = cvc.getTableMap();
		this.fetchAndPopulateTestDatabase(mainConn, testConn, assignmentId, questionId, query_id, course_id,datasetId, tm);
		cvc.closeConn();
	}

	public static void entry(String args[]) throws Exception{

		String datasetid=args[0];
		String assignment_id=args[1];
		String question_id = args[2];
		int questionId=Integer.parseInt(question_id);
		String course_id = args[3];
		//String questionid = "A"+assignment_id+"Q"+question_id+"S"+queryid;
		int query_id=1;
		if(args.length>3){
			query_id=Integer.parseInt(args[2]);

		}

		logger.log(Level.INFO,"------PopulateTestData-----entry()------");
		logger.log(Level.INFO,"Datasetid :"+datasetid);
		logger.log(Level.INFO,"QuestionId :"+query_id);
		GenerateCVC1 cvc = new GenerateCVC1();
		int assignId = Integer.parseInt(assignment_id);
		
		preProcessForDataGeneration pre = new preProcessForDataGeneration();
		cvc.setAssignmentId(assignId);
		cvc.setQuestionId(questionId);
		cvc.setQueryId(query_id);
		cvc.setCourseId(course_id);
		
		pre.initializeConnectionDetails(cvc);
		
		TableMap tm = cvc.getTableMap();
		PopulateTestDataGrading p=new PopulateTestDataGrading();
		p.fetchAndPopulateTestDatabase(Integer.parseInt(assignment_id), questionId,query_id, course_id, datasetid, tm);
		cvc.closeConn();

	}

	public static void main(String args[]) throws Exception{

		PopulateTestDataGrading p=new PopulateTestDataGrading();
		//p.generateCvcOutput("cvc3_9.cvc", "4/A1Q23");

	}

}
