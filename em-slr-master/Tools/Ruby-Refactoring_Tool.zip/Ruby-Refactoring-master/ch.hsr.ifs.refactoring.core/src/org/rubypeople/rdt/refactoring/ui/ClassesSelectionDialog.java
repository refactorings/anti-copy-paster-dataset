package org.rubypeople.rdt.refactoring.ui;

public interface ClassesSelectionDialog {
	
	String getSelectedName();
	
	int open();
}
