package org.rubypeople.rdt.refactoring.action;


public class RenameFileAction extends WorkbenchWindowActionDelegate {}
