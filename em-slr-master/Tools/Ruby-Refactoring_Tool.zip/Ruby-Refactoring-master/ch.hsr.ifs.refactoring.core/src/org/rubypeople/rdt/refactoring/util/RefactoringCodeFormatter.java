package org.rubypeople.rdt.refactoring.util;

public interface RefactoringCodeFormatter {
	String formatString(String code);
}
