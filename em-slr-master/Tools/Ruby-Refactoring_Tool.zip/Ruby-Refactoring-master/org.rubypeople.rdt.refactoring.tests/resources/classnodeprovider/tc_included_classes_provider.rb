class Class
  def method
  end
end

class Class
end


module M0
  class Class
  end
end
