module Modul
end

module Modul
  module Modul
  end
end

module Crap
  module Modul
  end
end