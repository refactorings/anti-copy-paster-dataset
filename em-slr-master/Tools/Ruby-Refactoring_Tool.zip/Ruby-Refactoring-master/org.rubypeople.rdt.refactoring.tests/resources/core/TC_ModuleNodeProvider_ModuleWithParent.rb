module OuterModule
  module Modul
  end
end