module M1
  module M2
    module M3
      module M4
        module M5
        end
      end
    end
  end
end