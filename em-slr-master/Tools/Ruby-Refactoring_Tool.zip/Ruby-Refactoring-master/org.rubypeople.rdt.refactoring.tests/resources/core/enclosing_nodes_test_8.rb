class Test
  def test
    a = 5
    b = 5 * a + 300
  end
end
