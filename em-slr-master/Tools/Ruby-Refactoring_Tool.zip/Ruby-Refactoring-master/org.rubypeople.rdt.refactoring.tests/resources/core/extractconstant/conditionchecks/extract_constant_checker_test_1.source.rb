class Test
  def method param
    puts param
  end
end