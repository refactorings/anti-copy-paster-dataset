Name = "Mirko"
puts "Hello " + Name