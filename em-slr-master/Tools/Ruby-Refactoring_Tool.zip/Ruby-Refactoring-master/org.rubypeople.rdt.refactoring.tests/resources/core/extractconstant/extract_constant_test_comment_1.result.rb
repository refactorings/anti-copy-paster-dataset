Name = "Mirko"
#before statement
puts "Hello " + Name #behind statement